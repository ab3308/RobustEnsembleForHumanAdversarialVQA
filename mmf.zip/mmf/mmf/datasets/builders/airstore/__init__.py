# Copyright (c) Facebook, Inc. and its affiliates.

from mmf.utils.env import import_files


import_files(__file__, "mmf.datasets.builders.airstore")
